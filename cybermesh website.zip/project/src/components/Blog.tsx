import { useTina } from 'tinacms/dist/react';

export default function Blog() {
  const { data } = useTina({
    query: `query getBlogPosts {
      postConnection {
        edges {
          node {
            title
            date
            category
            author
            body
          }
        }
      }
    }`,
    variables: {},
  });

  const posts = data?.postConnection?.edges?.map(edge => edge.node) || [];

  return (
    <section id="blog" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            Latest Insights
          </h2>
          <p className="mt-4 text-xl text-gray-400">
            Stay updated with the latest trends in cybersecurity and digital transformation
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {posts.map((post: any) => (
            <article
              key={post.title}
              className="bg-gray-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-cyan-500 transition-all"
            >
              <div className="p-6">
                <div className="flex items-center space-x-2 text-sm text-gray-400">
                  <span>{new Date(post.date).toLocaleDateString()}</span>
                  <span>•</span>
                  <span>{post.category}</span>
                </div>
                <h3 className="mt-2 text-xl font-semibold text-white">
                  {post.title}
                </h3>
                <div className="mt-3 text-gray-400 line-clamp-3">
                  {post.body?.children?.[0]?.children?.[0]?.text || ''}
                </div>
                <div className="mt-4">
                  <span className="text-cyan-500 hover:text-cyan-400 font-medium cursor-pointer">
                    Read more →
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}