import { Shield, Cloud, Megaphone, Server, Lock, Users } from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: Shield,
      title: 'Cybersecurity Consulting',
      description: 'Comprehensive security assessments and tailored solutions to protect your business from evolving threats.',
    },
    {
      icon: Cloud,
      title: 'Cloud Security & Migration',
      description: 'Secure cloud migration and management services with Azure and Microsoft 365 expertise.',
    },
    {
      icon: Megaphone,
      title: 'Digital Marketing',
      description: 'Strategic digital marketing solutions to enhance your online presence and drive growth.',
    },
    {
      icon: Server,
      title: 'Infrastructure Security',
      description: 'Robust infrastructure security design and implementation for maximum protection.',
    },
    {
      icon: Lock,
      title: 'Compliance & Risk Management',
      description: 'Ensure regulatory compliance and minimize security risks with our expert guidance.',
    },
    {
      icon: Users,
      title: 'Security Training',
      description: 'Comprehensive security awareness training for your team to build a strong security culture.',
    },
  ];

  return (
    <section id="services" className="py-24 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            Our Services
          </h2>
          <p className="mt-4 text-xl text-gray-400">
            Comprehensive cybersecurity and digital solutions for your business
          </p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <div
              key={service.title}
              className="relative group bg-gray-800 p-6 rounded-lg hover:bg-gray-700 transition-colors"
            >
              <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity blur" />
              <div className="relative bg-gray-800 p-6 rounded-lg">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-cyan-500 text-white">
                  <service.icon className="h-6 w-6" />
                </div>
                <h3 className="mt-8 text-lg font-medium text-white tracking-tight">
                  {service.title}
                </h3>
                <p className="mt-2 text-base text-gray-400">
                  {service.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}