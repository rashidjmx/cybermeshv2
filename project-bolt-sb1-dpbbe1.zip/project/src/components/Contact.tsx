import { Mail, Phone, MapPin } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-24 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            Contact Us
          </h2>
          <p className="mt-4 text-xl text-gray-400">
            Get in touch with us to discuss how we can help secure and grow your business
          </p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 lg:grid-cols-2">
          <div className="bg-gray-800 rounded-lg p-8">
            <form className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-300">
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  className="mt-1 block w-full rounded-md bg-gray-700 border-gray-600 text-white shadow-sm focus:border-cyan-500 focus:ring-cyan-500"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  className="mt-1 block w-full rounded-md bg-gray-700 border-gray-600 text-white shadow-sm focus:border-cyan-500 focus:ring-cyan-500"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300">
                  Message
                </label>
                <textarea
                  id="message"
                  rows={4}
                  className="mt-1 block w-full rounded-md bg-gray-700 border-gray-600 text-white shadow-sm focus:border-cyan-500 focus:ring-cyan-500"
                />
              </div>
              <button
                type="submit"
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-cyan-500 hover:bg-cyan-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500"
              >
                Send Message
              </button>
            </form>
          </div>

          <div className="bg-gray-800 rounded-lg p-8">
            <div className="space-y-8">
              <div className="flex items-start">
                <Mail className="h-6 w-6 text-cyan-500 mt-1" />
                <div className="ml-4">
                  <p className="text-lg font-medium text-white">Email</p>
                  <p className="text-gray-400">info@cybermesh.cloud</p>
                </div>
              </div>
              <div className="flex items-start">
                <Phone className="h-6 w-6 text-cyan-500 mt-1" />
                <div className="ml-4">
                  <p className="text-lg font-medium text-white">Phone</p>
                  <p className="text-gray-400">+254 700 000 000</p>
                </div>
              </div>
              <div className="flex items-start">
                <MapPin className="h-6 w-6 text-cyan-500 mt-1" />
                <div className="ml-4">
                  <p className="text-lg font-medium text-white">Location</p>
                  <p className="text-gray-400">Nairobi, Kenya</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}