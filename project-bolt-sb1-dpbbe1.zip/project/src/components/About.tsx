export default function About() {
  return (
    <section id="about" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 lg:items-center">
          <div>
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
              About Us
            </h2>
            <p className="mt-4 text-lg text-gray-400">
              Based in Nairobi, we are a team of certified cybersecurity and digital marketing experts dedicated to helping businesses in Kenya and Somalia thrive in the digital age.
            </p>
            <div className="mt-8">
              <div className="grid grid-cols-2 gap-8">
                {[
                  { number: '10+', label: 'Years Experience' },
                  { number: '200+', label: 'Clients Served' },
                  { number: '24/7', label: 'Support' },
                  { number: '99.9%', label: 'Success Rate' },
                ].map((stat) => (
                  <div key={stat.label} className="text-center">
                    <p className="text-4xl font-extrabold text-cyan-500">
                      {stat.number}
                    </p>
                    <p className="mt-2 text-sm text-gray-400">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="mt-10 lg:mt-0">
            <div className="aspect-w-16 aspect-h-9">
              <img
                className="rounded-lg shadow-xl ring-1 ring-black ring-opacity-5"
                src="https://images.unsplash.com/photo-1573164713988-8665fc963095?auto=format&fit=crop&q=80"
                alt="Cybersecurity team working"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}