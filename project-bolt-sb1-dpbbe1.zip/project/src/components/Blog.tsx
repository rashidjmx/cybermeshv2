import React from 'react';
import { Shield, Lock, Cloud } from 'lucide-react';

const posts = [
  {
    id: 1,
    title: 'Cybersecurity Best Practices for 2024',
    date: '2024-03-20',
    category: 'Cybersecurity',
    preview: 'Learn about the latest cybersecurity trends and how to protect your business from emerging threats.',
  },
  {
    id: 2,
    title: 'Cloud Migration Strategies',
    date: '2024-03-18',
    category: 'Cloud Services',
    preview: 'Discover the best practices for seamless cloud migration and optimization.',
  },
  {
    id: 3,
    title: 'Digital Marketing in the Age of Privacy',
    date: '2024-03-15',
    category: 'Digital Marketing',
    preview: 'Navigate the changing landscape of digital marketing with privacy-first strategies.',
  }
];

export default function Blog() {
  return (
    <section id="blog" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            Latest Insights
          </h2>
          <p className="mt-4 text-xl text-gray-400">
            Stay updated with the latest trends in cybersecurity and digital transformation
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {posts.map((post) => (
            <article
              key={post.id}
              className="bg-gray-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-cyan-500 transition-all"
            >
              <div className="p-6">
                <div className="flex items-center space-x-2 text-sm text-gray-400">
                  <span>{post.date}</span>
                  <span>•</span>
                  <span>{post.category}</span>
                </div>
                <h3 className="mt-2 text-xl font-semibold text-white">
                  {post.title}
                </h3>
                <div className="mt-3 text-gray-400 line-clamp-3">
                  {post.preview}
                </div>
                <div className="mt-4">
                  <span className="text-cyan-500 hover:text-cyan-400 font-medium cursor-pointer">
                    Read more →
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}