import { Shield, Lock, Cloud } from 'lucide-react';

interface HeroProps {
  data?: {
    heading?: string;
    subheading?: string;
  };
}

export default function Hero({ data }: HeroProps) {
  return (
    <div id="home" className="relative bg-black pt-16">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-black to-cyan-900 opacity-90" />
      </div>
      
      <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl">
            <span className="block">{data?.heading || 'Secure Your Digital Future'}</span>
            <span className="block text-cyan-500">{data?.subheading || 'with CyberMesh'}</span>
          </h1>
          <p className="mt-6 max-w-2xl mx-auto text-xl text-gray-300">
            Your trusted partner in cybersecurity and digital transformation. 
            We provide tailored solutions to protect your business and enhance your digital presence.
          </p>
          <div className="mt-10 flex justify-center gap-x-6">
            <a
              href="#contact"
              className="rounded-md bg-cyan-500 px-8 py-3 text-base font-medium text-white shadow hover:bg-cyan-600 transition-colors"
            >
              Get Started
            </a>
            <a
              href="#services"
              className="rounded-md bg-gray-800 px-8 py-3 text-base font-medium text-white shadow hover:bg-gray-700 transition-colors"
            >
              Learn More
            </a>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          {[
            {
              icon: Shield,
              title: 'Advanced Protection',
              description: 'State-of-the-art cybersecurity solutions to safeguard your digital assets',
            },
            {
              icon: Cloud,
              title: 'Cloud Excellence',
              description: 'Seamless cloud migration and management services',
            },
            {
              icon: Lock,
              title: 'Secure Infrastructure',
              description: 'Robust security infrastructure design and implementation',
            },
          ].map((feature) => (
            <div
              key={feature.title}
              className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-8 text-center"
            >
              <div className="flex justify-center">
                <feature.icon className="h-12 w-12 text-cyan-500" />
              </div>
              <h3 className="mt-6 text-xl font-medium text-white">{feature.title}</h3>
              <p className="mt-2 text-gray-300">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}