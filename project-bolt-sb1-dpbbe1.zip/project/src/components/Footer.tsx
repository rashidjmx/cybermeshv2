import { Shield } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2">
              <Shield className="h-8 w-8 text-cyan-500" />
              <span className="text-white font-bold text-xl">CyberMesh</span>
            </div>
            <p className="mt-4 text-gray-400">
              Securing your digital future with advanced cybersecurity solutions and expert services.
            </p>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-300 tracking-wider uppercase">
              Quick Links
            </h3>
            <ul className="mt-4 space-y-4">
              {['Home', 'Services', 'About', 'Contact', 'Blog'].map((item) => (
                <li key={item}>
                  <a href={`#${item.toLowerCase()}`} className="text-gray-400 hover:text-cyan-500">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-300 tracking-wider uppercase">
              Connect With Us
            </h3>
            <ul className="mt-4 space-y-4">
              {['LinkedIn', 'Twitter', 'Facebook', 'Instagram'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-400 hover:text-cyan-500">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-gray-800 pt-8">
          <p className="text-center text-gray-400">
            &copy; {new Date().getFullYear()} CyberMesh. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}