import { createClient } from "tinacms/dist/client";
import { queries } from "./types";
export const client = createClient({ url: 'http://localhost:4001/graphql', token: '697b1aa417e5c9b56a6f20f70a554cfe316901a9', queries,  });
export default client;
  